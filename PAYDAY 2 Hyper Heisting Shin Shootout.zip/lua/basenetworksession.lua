-- CREDIT:TEST1
BaseNetworkSession.CONNECTION_TIMEOUT = 40
BaseNetworkSession.LOADING_CONNECTION_TIMEOUT = SystemInfo:platform() == Idstring("WIN32") and 40
BaseNetworkSession._LOAD_WAIT_TIME = 10