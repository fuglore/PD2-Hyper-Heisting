function CriminalActionWalk:init(...)
	return CriminalActionWalk.super.init(self, ...)
end

function CriminalActionWalk:_get_max_walk_speed(...)
	return CriminalActionWalk.super._get_max_walk_speed(self, ...)
end

function CriminalActionWalk:_get_current_max_walk_speed(...)
	return CriminalActionWalk.super._get_current_max_walk_speed(self, ...)
end