function HuskCopMovement:sync_reload_weapon(empty_reload, reload_speed_multiplier)
    local reload_action = {
        body_part = 3,
        type = "reload",
        idle_reload = empty_reload ~= 0 and empty_reload or nil
    }

    self:action_request(reload_action)
end