--fuck you fuck you fuck you die

function SentryGunBase:unregister()
end

function SentryGunBase:register()
end