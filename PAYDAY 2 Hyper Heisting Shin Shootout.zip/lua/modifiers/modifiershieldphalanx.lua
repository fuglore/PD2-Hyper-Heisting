ModifierShieldPhalanx = ModifierShieldPhalanx or class(BaseModifier)
ModifierShieldPhalanx._type = "ModifierShieldPhalanx"
ModifierShieldPhalanx.name_id = "none"
ModifierShieldPhalanx.desc_id = "menu_cs_modifier_shield_phalanx"

function ModifierShieldPhalanx:init(data)
	ModifierShieldPhalanx.super.init(data)
	
	table.insert(tweak_data.group_ai.unit_categories.FBI_swat_R870.unit_types.america, Idstring("units/pd2_dlc_drm/characters/ene_city_swat_saiga/ene_city_swat_saiga"))
	
	table.insert(tweak_data.group_ai.unit_categories.FBI_swat_R870.unit_types.russia, Idstring("units/pd2_dlc_drm/characters/ene_city_swat_saiga/ene_city_swat_saiga"))
	
	table.insert(tweak_data.group_ai.unit_categories.FBI_swat_R870.unit_types.murkywater, Idstring("units/pd2_dlc_drm/characters/ene_city_swat_saiga/ene_city_swat_saiga"))
	
	table.insert(tweak_data.group_ai.unit_categories.FBI_swat_R870.unit_types.shared, Idstring("units/pd2_dlc_drm/characters/ene_city_swat_saiga/ene_city_swat_saiga"))
	
	if managers.modifiers and managers.modifiers:check_boolean("oopsallheavies") then
		table.insert(tweak_data.group_ai.unit_categories.FBI_heavy_R870.unit_types.america, Idstring("units/pd2_dlc_drm/characters/ene_city_swat_saiga/ene_city_swat_saiga"))
		table.insert(tweak_data.group_ai.unit_categories.FBI_heavy_R870.unit_types.russia, Idstring("units/pd2_dlc_drm/characters/ene_city_swat_saiga/ene_city_swat_saiga"))
		table.insert(tweak_data.group_ai.unit_categories.FBI_heavy_R870.unit_types.murkywater, Idstring("units/pd2_dlc_drm/characters/ene_city_swat_saiga/ene_city_swat_saiga"))
		table.insert(tweak_data.group_ai.unit_categories.FBI_heavy_R870.unit_types.shared, Idstring("units/pd2_dlc_drm/characters/ene_city_swat_saiga/ene_city_swat_saiga"))	
	end
	
	--tweak_data.group_ai.unit_categories.CS_shield = tweak_data.group_ai.unit_categories.Phalanx_minion
	--tweak_data.group_ai.unit_categories.FBI_shield = tweak_data.group_ai.unit_categories.Phalanx_minion
end

function ModifierShieldPhalanx:modify_value(id, value, unit)
	if dont then --dont
		--if id ~= "PlayerStandart:_start_action_intimidate" then
		--	return value
		--end

		--local unit_tweak = unit:base()._tweak_table

		--if unit_tweak ~= "phalanx_minion" then
		--	return value
		--end

		--if unit:base().is_phalanx then
		--	return
		--end

		--return "f31x_any"
	end
	
	return
end
